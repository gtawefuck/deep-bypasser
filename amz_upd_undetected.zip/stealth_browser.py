"""
Stealth Browser - Patchright-based browser with anti-detection features
Optimized for Amazon checking with patchright (undetected Playwright fork)
Best practice: use launch_persistent_context with channel="chrome"
"""

import asyncio
import random
import os
import sys
import tempfile
import shutil
from patchright.async_api import async_playwright, BrowserContext, Page


class StealthBrowser:
    """
    A stealth browser class that wraps Patchright with anti-detection features.
    Uses Google Chrome channel with persistent context for best stealth.
    No fingerprint injection needed - patchright handles everything.
    """
    
    def __init__(self, max_retries=3, window_position=None, proxy=None, headless=False):
        """
        Initialize the StealthBrowser.
        
        Args:
            max_retries: Maximum retry attempts for navigation
            window_position: Dict with 'x' and 'y' keys for window position
            proxy: Proxy configuration (dict with 'server', 'username', 'password' or string)
            headless: Whether to run browser in headless mode
        """
        self.playwright = None
        self.context = None  # In persistent mode, context IS the browser
        self.page = None
        self.on_waf = None  # Optional callback for WAF detection
        self.user_data_dir = None  # Temp directory for browser profile
        
        self.max_retries = max_retries
        self.window_position = window_position
        self.proxy = proxy
        self.headless = headless
    
    async def __aenter__(self):
        """Async context manager entry."""
        await self.start()
        return self
    
    async def __aexit__(self, exc_type, exc_val, exc_tb):
        """Async context manager exit."""
        await self.close()
    
    async def start(self):
        """
        Start the browser with patchright's stealth settings.
        Uses launch_persistent_context with Google Chrome for maximum stealth.
        This is the BEST PRACTICE recommended by patchright.
        """
        try:
            # Initialize Playwright if not already done
            if not self.playwright:
                self.playwright = await async_playwright().start()
            
            # Create a temp directory for user data (persistent context requirement)
            self.user_data_dir = tempfile.mkdtemp(prefix="patchright_")
            
            # Configure proxy
            proxy_config = None
            if self.proxy:
                try:
                    if isinstance(self.proxy, dict):
                        if 'server' in self.proxy:
                            server = self.proxy['server']
                            proxy_config = {'server': server}
                            print(f"[Browser] Using proxy: {server}")
                        
                        if self.proxy.get('username') and self.proxy.get('password'):
                            proxy_config['username'] = self.proxy['username']
                            proxy_config['password'] = self.proxy['password']
                            print(f"[Browser] Using proxy with auth: {self.proxy['username']}")
                    
                    elif isinstance(self.proxy, str):
                        proxy_config = {'server': self.proxy}
                        print(f"[Browser] Using proxy: {self.proxy}")
                
                except Exception as proxy_error:
                    print(f"[Browser] Proxy error: {proxy_error}, continuing without proxy")
            
            # Build launch args - include anti-webdriver flag
            launch_args = [
                '--disable-blink-features=AutomationControlled',  # Hide webdriver detection
            ]
            if self.window_position and not self.headless:
                x = self.window_position.get('x', 0)
                y = self.window_position.get('y', 0)
                launch_args.extend([
                    f"--window-position={x},{y}",
                ])
            
            # BEST PRACTICE: Use launch_persistent_context with channel="chrome"
            # This is the most undetectable configuration according to patchright docs
            self.context = await self.playwright.chromium.launch_persistent_context(
                user_data_dir=self.user_data_dir,
                channel="chrome",           # Use real Google Chrome
                headless=self.headless,
                no_viewport=True,           # Don't override viewport (more natural)
                args=launch_args if launch_args else None,
                proxy=proxy_config,
                # Set timezone and locale to match US proxy IP
                timezone_id="America/New_York",
                locale="en-US",
                # DO NOT add custom user_agent or headers - let Chrome use native
            )
            
            # Get first page or create new one
            if self.context.pages:
                self.page = self.context.pages[0]
            else:
                self.page = await self.context.new_page()
            
            print(f"[Browser] Browser started with Chrome persistent context (fully undetected)")
        
        except Exception as error:
            print(f"[Browser] Error starting browser: {error}")
            await self.close()
            raise error
    
    async def goto(self, url, **kwargs):
        """Navigate to a URL with a random delay."""
        await asyncio.sleep(random.uniform(0.5, 1.5))
        return await self.page.goto(url, **kwargs)
    
    async def human_type(self, selector, text):
        """
        Type text in a human-like manner with random delays between keystrokes.
        """
        await self.page.click(selector)
        await asyncio.sleep(random.uniform(0.05, 0.15))
        
        for char in text:
            await self.page.keyboard.type(char)
            await asyncio.sleep(random.uniform(0.02, 0.08))
    
    async def human_click(self, selector):
        """
        Click an element in a human-like manner (hover then click).
        """
        await self.page.hover(selector)
        await asyncio.sleep(random.uniform(0.05, 0.25))
        await self.page.click(selector)
    
    async def random_mouse_movement(self):
        """Perform random mouse movements to simulate human behavior."""
        for _ in range(random.randint(2, 5)):
            x = random.randint(100, 800)
            y = random.randint(100, 600)
            await self.page.mouse.move(x, y)
            await asyncio.sleep(random.uniform(0.1, 0.3))
    
    async def close(self):
        """Close and clean up all browser resources."""
        try:
            if self.page:
                await self.page.close()
                self.page = None
        except:
            pass
        
        try:
            if self.context:
                await self.context.close()
                self.context = None
        except:
            pass
        
        try:
            if self.playwright:
                await self.playwright.stop()
                self.playwright = None
        except:
            pass
        
        # Clean up temp user data directory
        try:
            if self.user_data_dir and os.path.exists(self.user_data_dir):
                shutil.rmtree(self.user_data_dir, ignore_errors=True)
                self.user_data_dir = None
        except:
            pass
    
    async def check_captcha_or_block(self):
        """
        Check if the page shows a captcha or is blocked.
        
        Returns:
            True if captcha/block detected, False otherwise
        """
        # Check for "Click the button below to continue shopping" message
        try:
            element = await self.page.wait_for_selector(
                'h4:has-text("Click the button below to continue shopping")',
                timeout=3000
            )
            if element:
                print("[Browser] Detected: 'Click the button below to continue shopping' - Browser blocked!")
                return True
        except:
            pass
        
        # Amazon WAF / Captcha indicators
        captcha_selectors = [
            '#aacb-captcha-header',
            'h1:has-text("Solve this puzzle")',
            'iframe[src*="captcha"]',
            '[id*="captcha"]'
        ]
        
        for selector in captcha_selectors:
            try:
                element = await self.page.wait_for_selector(selector, timeout=1500)
                if element:
                    print("[Browser] Detected: Amazon WAF/Captcha -", selector)
                    return True
            except:
                pass
        
        # Check for "Sorry! We couldn't find that page" error
        try:
            element = await self.page.wait_for_selector(
                'img[alt*="Sorry! We couldn\'t find that page"]',
                timeout=3000
            )
            if element:
                print("[Browser] Detected: 'Sorry! We couldn't find that page' - Page error!")
                return True
        except:
            pass
        
        # URL-based hints
        try:
            current_url = self.page.url.lower()
            if 'captcha' in current_url or '/ap/cvf/' in current_url:
                return True
        except:
            pass
        
        return False
    
    async def restart_browser(self):
        """Restart the browser with a fresh session."""
        print('[Browser] Restarting browser...')
        await self.close()
        await asyncio.sleep(random.uniform(1, 2))
        await self.start()
    
    async def goto_with_retry(self, url, **kwargs):
        """
        Navigate to a URL with automatic retry on captcha/block detection.
        
        Returns:
            True on success, False if max retries exceeded
        """
        for attempt in range(self.max_retries):
            try:
                print(f"[Browser] Attempt {attempt + 1}: Navigating to {url[:50]}...")
                await self.goto(url, **kwargs)
                
                if await self.check_captcha_or_block():
                    # Optional external handler to rotate proxy on WAF
                    try:
                        if getattr(self, 'on_waf', None):
                            await self.on_waf()
                    except Exception as waf_error:
                        print(f"[Browser] on_waf handler error: {waf_error}")
                    
                    if attempt < self.max_retries - 1:
                        await self.restart_browser()
                        continue
                    else:
                        print(f"[Browser] Max retries reached for {url}")
                        return False
                
                return True
            
            except Exception as nav_error:
                print(f"[Browser] Navigation error: {nav_error}")
                
                if attempt < self.max_retries - 1:
                    await self.restart_browser()
                    continue
                else:
                    print(f"[Browser] Max retries reached, giving up")
                    return False
        
        return False


async def patch_context(context):
    """
    Apply stealth patches to an existing browser context.
    Note: With patchright, most patches are already applied automatically.
    """
    print('[Stealth] Context ready with patchright stealth patches')